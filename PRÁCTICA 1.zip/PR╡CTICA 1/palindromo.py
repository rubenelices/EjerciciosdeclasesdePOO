class Palindromo:
    def __init__(self, palabra):
        self.palabra = palabra
        self.atributo = palabra  # Nuevo atributo

    def get_palabra(self):
        return self.palabra
    
    def es_palindromo(self):
        palabra = self.palabra.replace('', '').lower()
        return palabra == palabra[::-1]

    def resultado(self):
        if self.es_palindromo():
            return f"La palabra {self.palabra} es un palíndromo"
        else:
            return f"La palabra {self.palabra} no es un palíndromo"

    def test(self):
        return (self.es_palindromo(), self.palabra.upper())

    def __del__(self):
        print(self.atributo.upper())

    def __str__(self):
        return self.resultado()

def main():
    palabra = input("Escribe una palabra: ")
    palindromo = Palindromo(palabra)
    print(palindromo)

if __name__ == "__main__":
    main()

