class Logger:
    def __init__(self):
        self.log_count = 0
        self.log_file = open("log.txt", "w")
        self.log_file.write("--Start log--\n")

    def log(self, mensaje):
        self.log_count += 1
        self.log_file.write(f"{mensaje}\n")

    def __del__(self):
        self.log_file.write(f"--End log: {self.log_count} log(s)--")
        self.log_file.close()

class Test:
    def __init__(self):
        self.logger = Logger()

    def llamada(self, mensaje):
        self.logger.log(mensaje)

# Uso de la clase Test
test = Test()
for i in range(1, 6):
    if i == 1:
        test.llamada("Primera llamada")
    else:
        test.llamada(f"{i}a llamada")

